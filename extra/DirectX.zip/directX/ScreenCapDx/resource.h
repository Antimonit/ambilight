//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ScreenCapture.rc
//
#define IDC_MYICON                      2
#define IDD_SCREENCAPTURE_DIALOG        102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_SCREENCAPTURE               107
#define IDI_SMALL                       108
#define IDC_SCREENCAPTURE               109
#define IDR_MAINFRAME                   128
#define ID_CAPTURE_START                129
#define ID_CAPTURE_STOP                 130
#define ID_FILE_SHOWWINDOW              131
#define ID_EDIT_COPYTOCLIPBOARD         132
#define ID_FILE_HIDEWINDOW              133
#define ID_EDIT_COPYSCREENSHOTTOCLIPBOARD 134
#define ID_EDIT_SAVEASBMP               135
#define ID_FILE_CAPTURESCREENSHOT       136
#define ID_FILE_STARTCAPTURINGTOAVI     137
#define ID_FILE_PAUSECAPTURINGTOAVI     138
#define IDI_ICON_PAUSE                  139
#define IDI_ICON_START                  140
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
